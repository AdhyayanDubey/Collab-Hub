import { redirect } from "next/navigation"

export default function HomePage() {
  // Redirect to the workspace page
  redirect("/workspaces")
}

